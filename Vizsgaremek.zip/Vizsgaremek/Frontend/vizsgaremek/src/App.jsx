import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Regions from './pages/Regions';
import Programs from './pages/Programs';
import Booking from './pages/Booking';
import About from './pages/About';
import Success from './pages/Success';
import './App.css';

function App() {
  return (
    <div className="App">
      <Navbar />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/tajegysgek" element={<Regions />} />
          <Route path="/programok" element={<Programs />} />
          <Route path="/foglalas" element={<Booking />} />
          <Route path="/rolunk" element={<About />} />
          <Route path="/sikeres-foglalas" element={<Success />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

export default App;