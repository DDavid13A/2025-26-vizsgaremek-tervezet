export const PROGRAM_PRICES = {
  etterem: 8900,
  fozokurzus: 12500,
  pincelatogatas: 9500,
  gasztrotura: 25000,
  piac: 15000,
  fesztival: 5000
};

export const PROGRAM_NAMES = {
  etterem: 'Étterem Kóstoló',
  fozokurzus: 'Főzőkurzus',
  pincelatogatas: 'Pincelátogatás',
  gasztrotura: 'Tematikus Gasztrotúra',
  piac: 'Piaci vásárlás és főzés',
  fesztival: 'Gasztro Fesztivál'
};

export const PROGRAM_REGIONS = {
  etterem: ['Balaton-felvidék', 'Alföld', 'Budapest', 'Észak-Magyarország', 'Dél-Dunántúl', 'Nyugat-Dunántúl'],
  fozokurzus: ['Budapest', 'Balaton-felvidék', 'Alföld'],
  pincelatogatas: ['Tokaj-Hegyalja', 'Villány', 'Balaton-felvidék', 'Etyek-Buda'],
  gasztrotura: ['Balaton-felvidék', 'Budapest és környéke', 'Tokaj-Hegyalja'],
  piac: ['Budapest', 'Szeged', 'Debrecen'],
  fesztival: ['Budapest', 'Balaton-felvidék', 'Szeged', 'Tokaj']
};

export const REGIONS_DATA = [
  {
    id: 'balaton',
    name: 'Balaton-felvidék',
    description: 'A halászlék, a balatoni fogások és a kiváló borvidékek régiója. Kóstold meg a friss fogást a Balaton partján, vagy a badacsonyi szürkebaráttal párosított helyi specialitásokat.',
    image: 'https://images.unsplash.com/photo-1596195689407-9fd324c743c5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    specialties: ['Balatoni halászlé', 'Fogas sült', 'Badacsonyi borokkal készült ételek'],
    wineRegions: ['Badacsony', 'Balatonfelvidék', 'Balatonboglár']
  },
  {
    id: 'alfold',
    name: 'Alföld',
    description: 'A pásztorhagymás halászlé, a debreceni és szegedi kolbász, valamint a házi készítésű tészták birodalma. Fedezd fel az Alföld gazdag húsételeit és házias ízeit.',
    image: 'https://images.unsplash.com/photo-1578661556446-57aedffafb42?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    specialties: ['Szegedi halászlé', 'Debreceni kolbász', 'Hortobágyi húsos palacsinta'],
    cities: ['Szeged - halászlé fővárosa', 'Debrecen - kolbász városa', 'Kecskemét - Barackpálinka fővárosa']
  },
  {
    id: 'budapest',
    name: 'Budapest',
    description: 'A főváros sokszínű gasztroárnyalatai - a tradicionális magyar konyhától a modern új magyar gasztronómiáig. Élvezd a városi gasztroélményeket világszínvonalon.',
    image: 'https://images.unsplash.com/photo-1596199050105-6d5d4c4c5e3a?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    experiences: ['Új magyar gasztronómia', 'Budapesti kávéház kultúra', 'Városi borozók és borpincék'],
    places: ['Budavári palota környéke', 'Gozsdu udvar', 'Hold utca piac']
  }
];

export const PROGRAMS_DATA = [
  {
    id: 'etterem-kostolo',
    name: 'Étterem Kóstoló',
    description: 'Ismerd meg a legjobb helyi éttermeket kóstolómenü keretében. Minden étteremben 5 fogásos menüt kínálunk, melyek a terület jellegzetes ízeit mutatják be.',
    icon: 'cup-hot',
    duration: '2-3 óra',
    price: 8900,
    minParticipants: 2,
    maxParticipants: 12,
    availableRegions: 'Mind'
  },
  {
    id: 'fozokurzus',
    name: 'Főzőkurzus',
    description: 'Tanuld meg elkészíteni a hagyományos magyar ételeket helyi szakácsok vezetésével. A kurzus végén közösen megkóstoljátok a kész fogásokat.',
    icon: 'mortarboard',
    duration: '4-5 óra',
    price: 12500,
    minParticipants: 4,
    maxParticipants: 10,
    availableRegions: 'Budapest, Balaton, Alföld'
  },
  {
    id: 'pincelatogatas',
    name: 'Pincelátogatás',
    description: 'Fedezd fel a magyar borvidékeket pincelátogatások keretében. Kóstold meg a legjobb borokat, és ismerd meg a borászatok titkait.',
    icon: 'droplet',
    duration: '3-4 óra',
    price: 9500,
    minParticipants: 2,
    maxParticipants: 15,
    availableRegions: 'Tokaj, Villány, Balaton, Etyek'
  },
  {
    id: 'gasztrotura',
    name: 'Tematikus Gasztrotúra',
    description: 'Egy vagy több napos gasztronómiai túrák, melyek során több éttermet, borkostolót és helyi termelőt is megismerkedsz.',
    icon: 'geo-alt',
    duration: '1-3 nap',
    price: 25000,
    minParticipants: 4,
    maxParticipants: 8,
    availableRegions: 'Balaton, Budapest, Tokaj'
  },
  {
    id: 'piac',
    name: 'Piaci vásárlás és főzés',
    description: 'Egy helyi piacról indulva választjuk ki a legjobb alapanyagokat, majd együtt elkészítjük belőlük a fogásokat egy professzionális konyhában.',
    icon: 'basket',
    duration: '5-6 óra',
    price: 15000,
    minParticipants: 3,
    maxParticipants: 8,
    availableRegions: 'Budapest, Szeged, Debrecen'
  },
  {
    id: 'fesztival',
    name: 'Gasztro Fesztivál',
    description: 'Vegyél részt a legnépszerűbb gasztronómiai fesztiválokon országos szinten. Kapcsolódj be a helyi gasztroeseményekbe és ünnepekbe.',
    icon: 'calendar-event',
    duration: 'változó (fél-egész nap)',
    price: 5000,
    minParticipants: 1,
    maxParticipants: 'Korlátlan',
    availableRegions: 'Mind, szezonális'
  }
];