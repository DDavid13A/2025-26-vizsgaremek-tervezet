import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import './Navbar.css';

const Navbar = () => {
  const location = useLocation();

  const isActive = (path) => {
    return location.pathname === path ? 'active' : '';
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-light fixed-top">
      <div className="container">
        <Link className="navbar-brand d-flex align-items-center" to="/">
          <i className="bi bi-shop-window text-danger me-2 fs-3"></i>
          <span className="text-danger">Gasztro</span>
          <span className="text-success">Magyarország</span>
        </Link>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item">
              <Link className={`nav-link ${isActive('/')}`} to="/">Kezdőlap</Link>
            </li>
            <li className="nav-item">
              <Link className={`nav-link ${isActive('/tajegysgek')}`} to="/tajegysgek">Tájegységek</Link>
            </li>
            <li className="nav-item">
              <Link className={`nav-link ${isActive('/programok')}`} to="/programok">Programok</Link>
            </li>
            <li className="nav-item">
              <Link className={`nav-link ${isActive('/foglalas')}`} to="/foglalas">Foglalás</Link>
            </li>
            <li className="nav-item">
              <Link className={`nav-link ${isActive('/rolunk')}`} to="/rolunk">Rólunk</Link>
            </li>
            <li className="nav-item ms-lg-2 mt-2 mt-lg-0">
              <Link className="btn btn-primary" to="/foglalas">Foglalj most!</Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;