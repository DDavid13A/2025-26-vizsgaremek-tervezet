import React from 'react';
import { Link } from 'react-router-dom';
import './Footer.css';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">
        <div className="row">
          <div className="col-lg-4 col-md-6 mb-4">
            <h4 className="footer-heading">
              <i className="bi bi-shop-window me-2"></i>GasztroMagyarország
            </h4>
            <p>Magyarország gasztroturisztikai élményeit bemutató és könnyen elérhetővé tevő portál. Fedezd fel velünk az ország gasztronómiai kincseit!</p>
            <div className="d-flex mt-4">
              <a href="#" className="text-white me-3"><i className="bi bi-facebook fs-5"></i></a>
              <a href="#" className="text-white me-3"><i className="bi bi-instagram fs-5"></i></a>
              <a href="#" className="text-white me-3"><i className="bi bi-tiktok fs-5"></i></a>
              <a href="#" className="text-white"><i className="bi bi-youtube fs-5"></i></a>
            </div>
          </div>
          
          <div className="col-lg-2 col-md-6 mb-4">
            <h5 className="footer-heading">Oldaltérkép</h5>
            <div className="footer-links">
              <Link to="/">Kezdőlap</Link>
              <Link to="/tajegysgek">Tájegységek</Link>
              <Link to="/programok">Programok</Link>
              <Link to="/foglalas">Foglalás</Link>
              <Link to="/rolunk">Rólunk</Link>
            </div>
          </div>
          
          <div className="col-lg-3 col-md-6 mb-4">
            <h5 className="footer-heading">Népszerű Programok</h5>
            <div className="footer-links">
              <Link to="/programok#etterem-kostolo">Étterem Kóstoló</Link>
              <Link to="/programok#fozokurzus">Főzőkurzus</Link>
              <Link to="/programok#pincelatogatas">Pincelátogatás</Link>
              <Link to="/programok#gasztrotura">Gasztrotúra</Link>
              <Link to="/programok#piac">Piaci vásárlás</Link>
            </div>
          </div>
          
          <div className="col-lg-3 col-md-6 mb-4">
            <h5 className="footer-heading">Kapcsolat</h5>
            <div className="footer-links">
              <p><i className="bi bi-telephone me-2"></i>+36 1 234 5678</p>
              <p><i className="bi bi-envelope me-2"></i>info@gasztromagyarorszag.hu</p>
              <p><i className="bi bi-geo-alt me-2"></i>1052 Budapest, Petőfi Sándor utca 5.</p>
              <p><i className="bi bi-clock me-2"></i>H-P: 9:00-18:00</p>
            </div>
          </div>
        </div>
        
        <div className="copyright">
          <p>&copy; 2023 GasztroMagyarország. Minden jog fenntartva. | Vizsgaremek: Almássy Benedek & Solt Dorfinger Dávid</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;