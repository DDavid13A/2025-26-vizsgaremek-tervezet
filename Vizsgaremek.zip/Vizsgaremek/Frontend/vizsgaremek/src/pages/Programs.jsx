import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { PROGRAMS_DATA } from '../data/constants';
import './Programs.css';

const Programs = () => {
  const [activeFilter, setActiveFilter] = useState('all');
  
  const programFilters = [
    { id: 'all', label: 'Összes' },
    { id: 'kostolo', label: 'Kóstolók' },
    { id: 'fozes', label: 'Főzés' },
    { id: 'bor', label: 'Bor&Szőlő' },
    { id: 'tura', label: 'Túrák' },
    { id: 'fesztival', label: 'Fesztiválok' }
  ];

  const programCategories = {
    'etterem-kostolo': 'kostolo',
    'fozokurzus': 'fozes',
    'pincelatogatas': 'bor',
    'gasztrotura': 'tura',
    'piac': 'fozes',
    'fesztival': 'fesztival'
  };

  const filteredPrograms = activeFilter === 'all' 
    ? PROGRAMS_DATA 
    : PROGRAMS_DATA.filter(program => programCategories[program.id] === activeFilter);

  return (
    <div className="programs-page">
      {/* Page Header */}
      <section className="page-header">
        <div className="container">
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item"><Link to="/">Kezdőlap</Link></li>
              <li className="breadcrumb-item active" aria-current="page">Programok</li>
            </ol>
          </nav>
          <h1>Gasztroprogramjaink</h1>
          <p className="lead">
            Válassz a változatos gasztronómiai programjaink közül - akár egy rövid kóstolót, 
            akár egy többnapos gasztrotúrát szeretnél!
          </p>
        </div>
      </section>

      {/* Program Filter */}
      <section className="py-4 bg-light">
        <div className="container">
          <div className="d-flex flex-wrap justify-content-center gap-2">
            {programFilters.map(filter => (
              <button
                key={filter.id}
                className={`btn btn-outline-primary program-filter ${activeFilter === filter.id ? 'active' : ''}`}
                onClick={() => setActiveFilter(filter.id)}
                data-program={filter.id}
              >
                {filter.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Programs Grid */}
      <section className="py-5">
        <div className="container">
          <div className="row g-4">
            {filteredPrograms.map(program => (
              <div className="col-lg-4 col-md-6" key={program.id} id={program.id}>
                <div className="program-card">
                  <div className="program-icon">
                    <i className={`bi bi-${program.icon}`}></i>
                  </div>
                  <h4>{program.name}</h4>
                  <p>{program.description}</p>
                  
                  <div className="program-info-box mt-3">
                    <h6>Program részletei:</h6>
                    <p><strong>Időtartam:</strong> {program.duration}</p>
                    <p><strong>Ár:</strong> {program.price.toLocaleString('hu-HU')} Ft/fő</p>
                    <p><strong>Min. létszám:</strong> {program.minParticipants} fő</p>
                    <p><strong>Max. létszám:</strong> {program.maxParticipants} fő</p>
                    <p><strong>Elérhető régiók:</strong> {program.availableRegions}</p>
                  </div>
                  
                  <div className="program-schedule">
                    <h6>Tipikus menetrend:</h6>
                    <ol>
                      <li>Üdvözlés és bemutatkozás (15 perc)</li>
                      <li>Előételek kóstolása (30 perc)</li>
                      <li>Főételek kóstolása (60 perc)</li>
                      <li>Desszertek és borok (45 perc)</li>
                    </ol>
                  </div>
                  
                  <div className="mt-3">
                    <Link to={`/foglalas?program=${program.id.split('-')[0]}`} className="btn btn-primary">
                      Foglalás most
                    </Link>
                    <button className="btn btn-outline-primary ms-2" data-bs-toggle="modal" data-bs-target={`#programModal${program.id}`}>
                      Részletek
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Program Comparison */}
      <section className="py-5 bg-light">
        <div className="container">
          <div className="row mb-5">
            <div className="col-lg-8 mx-auto text-center">
              <h2 className="section-title text-center">Programok összehasonlítása</h2>
              <p className="lead">Válaszd ki számodra leginkább megfelelő gasztroprogramot!</p>
            </div>
          </div>
          
          <div className="table-responsive">
            <table className="table table-hover">
              <thead>
                <tr>
                  <th>Program</th>
                  <th>Ideális időtartam</th>
                  <th>Ár/fő</th>
                  <th>Csoportméret</th>
                  <th>Élmény típusa</th>
                  <th>Legjobb időpont</th>
                </tr>
              </thead>
              <tbody>
                {PROGRAMS_DATA.map(program => (
                  <tr key={program.id}>
                    <td><strong>{program.name}</strong></td>
                    <td>{program.duration}</td>
                    <td>{program.price.toLocaleString('hu-HU')} Ft</td>
                    <td>{program.minParticipants}-{program.maxParticipants} fő</td>
                    <td>
                      {program.id === 'etterem-kostolo' && 'Fogyasztás, ismerkedés'}
                      {program.id === 'fozokurzus' && 'Aktív részvétel'}
                      {program.id === 'pincelatogatas' && 'Kóstolás, tanulás'}
                      {program.id === 'gasztrotura' && 'Felfedezés, utazás'}
                      {program.id === 'piac' && 'Aktív, piaci'}
                      {program.id === 'fesztival' && 'Ünnep, közösség'}
                    </td>
                    <td>
                      {program.id === 'etterem-kostolo' && 'Este (18-21h)'}
                      {program.id === 'fozokurzus' && 'Délután (14-19h)'}
                      {program.id === 'pincelatogatas' && 'Délután (15-19h)'}
                      {program.id === 'gasztrotura' && 'Egész nap'}
                      {program.id === 'piac' && 'Délelőtt (9-15h)'}
                      {program.id === 'fesztival' && 'Szombat-Vasárnap'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-5">
        <div className="container">
          <div className="row mb-5">
            <div className="col-lg-8 mx-auto text-center">
              <h2 className="section-title text-center">Gyakran Ismételt Kérdések</h2>
              <p className="lead">Válaszok a leggyakoribb kérdésekre programjainkkal kapcsolatban</p>
            </div>
          </div>
          
          <div className="row">
            <div className="col-lg-6">
              <div className="accordion" id="faqAccordion">
                <div className="accordion-item">
                  <h2 className="accordion-header" id="headingOne">
                    <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne">
                      Milyen diétai igényeket tudtok kielégíteni?
                    </button>
                  </h2>
                  <div id="collapseOne" className="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
                    <div className="accordion-body">
                      <p>Minden programunkon figyelembe vesszük a speciális diétai igényeket (vegetáriánus, vegán, gluténmentes, laktózmentes, allergiák). Kérjük, a foglaláskor jelezze ezeket az igényeket.</p>
                    </div>
                  </div>
                </div>
                
                <div className="accordion-item">
                  <h2 className="accordion-header" id="headingTwo">
                    <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo">
                      Mi történik rossz időjárás esetén?
                    </button>
                  </h2>
                  <div id="collapseTwo" className="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                    <div className="accordion-body">
                      <p>Beltéri programjaink bármilyen időjárás mellett megrendezhetők. A szabadtéri programok esetén alternatív helyszíneket biztosítunk, vagy átütemezzük a programot.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="col-lg-6">
              <div className="accordion" id="faqAccordion2">
                <div className="accordion-item">
                  <h2 className="accordion-header" id="headingThree">
                    <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree">
                      Mennyi idővel előre kell foglalni?
                    </button>
                  </h2>
                  <div id="collapseThree" className="accordion-collapse collapse" data-bs-parent="#faqAccordion2">
                    <div className="accordion-body">
                      <p>Ajánlott legalább 3-7 nappal előre foglalni. Legkorábban 3 hónappal, legkésőbb 24 órával előre lehet foglalni.</p>
                    </div>
                  </div>
                </div>
                
                <div className="accordion-item">
                  <h2 className="accordion-header" id="headingFour">
                    <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour">
                      Mik a lemondási feltételek?
                    </button>
                  </h2>
                  <div id="collapseFour" className="accordion-collapse collapse" data-bs-parent="#faqAccordion2">
                    <div className="accordion-body">
                      <p><strong>48 órán belüli lemondás:</strong> 50% visszatérítés<br />
                      <strong>24 órán belüli lemondás:</strong> nincs visszatérítés<br />
                      <strong>Egészségügyi okok:</strong> orvosi igazolás esetén teljes visszatérítés</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-5 bg-primary text-white">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-lg-8">
              <h2 className="display-6 fw-bold">Találtad meg az álmaid gasztroprogramját?</h2>
              <p className="lead mb-0">Foglalj időpontot még ma, és élvezd a felejthetetlen gasztroélményt!</p>
            </div>
            <div className="col-lg-4 text-lg-end text-center mt-4 mt-lg-0">
              <Link to="/foglalas" className="btn btn-light btn-lg px-5">Foglalás most</Link>
            </div>
          </div>
        </div>
      </section>

      {/* Program Modals */}
      {PROGRAMS_DATA.map(program => (
        <div className="modal fade" id={`programModal${program.id}`} tabindex="-1" key={program.id}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">{program.name} - Részletek</h5>
                <button type="button" className="btn-close" data-bs-dismiss="modal"></button>
              </div>
              <div className="modal-body">
                <p>{program.description}</p>
                <h6>Mit tartalmaz a program?</h6>
                <ul>
                  <li>3 különböző étterem látogatása</li>
                  <li>15 különböző fogás megkóstolása</li>
                  <li>Hozzá illő borok és italok</li>
                  <li>Szakmai bemutató a séfektől</li>
                </ul>
                <h6>Fontos információk:</h6>
                <ul>
                  <li>Ár: {program.price.toLocaleString('hu-HU')} Ft/fő</li>
                  <li>Időtartam: {program.duration}</li>
                  <li>Maximum {program.maxParticipants} fős csoportokban</li>
                </ul>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Bezárás</button>
                <Link to={`/foglalas?program=${program.id.split('-')[0]}`} className="btn btn-primary">Foglalás</Link>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Programs;