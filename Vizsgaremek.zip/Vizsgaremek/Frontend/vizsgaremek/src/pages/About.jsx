import React from 'react';
import { Link } from 'react-router-dom';
import './About.css';

const About = () => {
  const teamMembers = [
    {
      id: 1,
      name: 'Almássy Benedek Solt',
      role: 'Ügyvezető & Gasztronómiai Szakértő',
      description: 'Benedek gasztronómiai családból származik - a család több generációja is a vendéglátásban dolgozott. Szakácsnak tanult, majd turisztikát végzett az egyetemen.',
      image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80',
      favoriteFood: 'Kedvenc magyar étele: Szegedi halászlé'
    },
    {
      id: 2,
      name: 'Dorfinger Dávid',
      role: 'Technikai Igazgató & Fejlesztő',
      description: 'Dávid informatikusként kezdte, de szenvedélye mindig is a gasztronómia volt. Számos kulináris blogot írt, mielőtt úgy döntött, hogy összeköti két szeretetét.',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80',
      favoriteFood: 'Kedvenc magyar étele: Rakott krumpli'
    },
    {
      id: 3,
      name: 'Kovács Eszter',
      role: 'Gasztrokalauz',
      description: '5 éve vezet gasztrotúrákat, tökéletesen beszél angolul és németül.',
      image: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80'
    },
    {
      id: 4,
      name: 'Nagy Péter',
      role: 'Szakács & Oktató',
      description: 'Michelin-csillagos étteremben dolgozott, most a hagyományos magyar konyhát tanítja.',
      image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80'
    }
  ];

  const values = [
    {
      icon: 'shield-check',
      title: 'Autentikusság',
      description: 'Csak valódi, helyi élményeket kínálunk. Minden programunkat helyi szakértők vezetnek, akik mély ismerettel rendelkeznek a régió kulináris hagyományairól.'
    },
    {
      icon: 'people',
      title: 'Közösség',
      description: 'Hiszünk abban, hogy az étel összehozza az embereket. Programjaink nem csak gasztroélmények, hanem lehetőségek új kapcsolatok építésére is.'
    },
    {
      icon: 'tree',
      title: 'Fenntarthatóság',
      description: 'Helyi termelőket támogatunk, szezonális alapanyagokat használunk, és minimalizáljuk az ökológiai lábnyomunkat minden programunk során.'
    }
  ];

  return (
    <div className="about-page">
      {/* Page Header */}
      <section className="page-header">
        <div className="container">
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item"><Link to="/">Kezdőlap</Link></li>
              <li className="breadcrumb-item active" aria-current="page">Rólunk</li>
            </ol>
          </nav>
          <h1>Rólunk</h1>
          <p className="lead">Ismerd meg a GasztroMagyarország csapatát és küldetésünket!</p>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-5">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-lg-6">
              <h2 className="section-title">A történetünk</h2>
              <p>
                A GasztroMagyarország 2020-ban alakult, amikor két gasztronómiai szenvedélyes fiatal, 
                Almássy Benedek és Solt Dorfinger Dávid úgy döntött, hogy összehozza szeretetüket a 
                magyar konyha iránt és a modern technológia lehetőségeit.
              </p>
              
              <p>
                Egy nyári napon, egy budapesti piacon történt beszélgetés során jöttünk rá, 
                hogy hiány van egy olyan platformból, amely összeköti az érdeklődő utazókat a 
                valódi magyar gasztronómiai élményekkel. Sok turista csak a legismertebb ételeket ismeri, 
                de nem tudja, hol találhatja meg a legjobb, legautentikusabb változataikat.
              </p>
              
              <p>
                Így született meg az ötlet: egy olyan weboldal, amely nem csak információkat közöl, 
                hanem közvetlen kapcsolatot teremt a gasztroélmények és azok élvezői között.
              </p>
            </div>
            <div className="col-lg-6">
              <img 
                src="https://images.unsplash.com/photo-1559925393-8be0ec4767c8?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                className="img-fluid rounded shadow" 
                alt="GasztroMagyarország csapat" 
              />
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-5 bg-light">
        <div className="container">
          <div className="row">
            <div className="col-lg-6 mb-5 mb-lg-0">
              <div className="card border-0 h-100 shadow-sm">
                <div className="card-body p-5">
                  <div className="feature-icon mx-auto mb-4">
                    <i className="bi bi-bullseye"></i>
                  </div>
                  <h3 className="text-center mb-4">Küldetésünk</h3>
                  <p className="text-center">
                    Magyarország gasztronómiai kincseinek bemutatása és népszerűsítése mind hazai, 
                    mind nemzetközi látogatók számára. Célunk, hogy mindenki megismerhesse a valódi 
                    magyar ízeket, és felejthetetlen gasztroélményekben legyen része.
                  </p>
                </div>
              </div>
            </div>
            <div className="col-lg-6">
              <div className="card border-0 h-100 shadow-sm">
                <div className="card-body p-5">
                  <div className="feature-icon mx-auto mb-4">
                    <i className="bi bi-eye"></i>
                  </div>
                  <h3 className="text-center mb-4">Víziónk</h3>
                  <p className="text-center">
                    Szeretnénk, ha Magyarország az európai gasztroturizmus egyik vezető országa lenne. 
                    Elképzelésünk szerint minden vendég úgy tér haza, hogy nemcsak a magyar konyha ízeit, 
                    hanem annak történetét, hagyományait és kultúráját is megismerte.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Team Members */}
      <section className="py-5">
        <div className="container">
          <div className="row mb-5">
            <div className="col-lg-8 mx-auto text-center">
              <h2 className="section-title text-center">Csapatunk</h2>
              <p className="lead">Ismerd meg a GasztroMagyarország mögött álló embereket!</p>
            </div>
          </div>
          
          <div className="row g-4">
            {teamMembers.slice(0, 2).map(member => (
              <div className="col-lg-6" key={member.id}>
                <div className="card border-0 shadow h-100">
                  <div className="row g-0">
                    <div className="col-md-4">
                      <img 
                        src={member.image} 
                        className="img-fluid rounded-start h-100" 
                        alt={member.name}
                        style={{ objectFit: 'cover' }}
                      />
                    </div>
                    <div className="col-md-8">
                      <div className="card-body">
                        <h4 className="card-title">{member.name}</h4>
                        <h6 className="text-primary mb-3">{member.role}</h6>
                        <p className="card-text">{member.description}</p>
                        {member.favoriteFood && (
                          <p className="card-text">
                            <small className="text-muted">{member.favoriteFood}</small>
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {/* Additional Team Members */}
          <div className="row g-4 mt-2">
            {teamMembers.slice(2).map(member => (
              <div className="col-lg-3 col-md-6" key={member.id}>
                <div className="card border-0 text-center h-100">
                  <div className="card-body">
                    <img 
                      src={member.image} 
                      className="rounded-circle mb-3" 
                      alt={member.name}
                      width="120"
                      height="120"
                      style={{ objectFit: 'cover' }}
                    />
                    <h5>{member.name}</h5>
                    <p className="text-primary">{member.role}</p>
                    <p className="small">{member.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-5 bg-light">
        <div className="container">
          <div className="row mb-5">
            <div className="col-lg-8 mx-auto text-center">
              <h2 className="section-title text-center">Értékeink</h2>
              <p className="lead">Ezek az alapértékek vezetnek minket minden nap</p>
            </div>
          </div>
          
          <div className="row g-4">
            {values.map((value, index) => (
              <div className="col-md-4" key={index}>
                <div className="text-center p-4">
                  <div className="feature-icon mx-auto mb-4">
                    <i className={`bi bi-${value.icon}`}></i>
                  </div>
                  <h4>{value.title}</h4>
                  <p>{value.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Partners */}
      <section className="py-5">
        <div className="container">
          <div className="row mb-5">
            <div className="col-lg-8 mx-auto text-center">
              <h2 className="section-title text-center">Partnereink</h2>
              <p className="lead">Minőségi programjainkat kiváló partnereink teszik lehetővé</p>
            </div>
          </div>
          
          <div className="row g-4">
            {['Budapest Gasztro Kör', 'Balatoni Halászok', 'Tokaji Borút', 'Alföldi Parasztkonyha'].map((partner, index) => (
              <div className="col-md-3 col-6 text-center" key={index}>
                <div className="p-4 border rounded">
                  <h5 className="text-primary">{partner}</h5>
                  <p className="small">
                    {index === 0 && 'Városi gasztroélmények'}
                    {index === 1 && 'Friss halfeldolgozás'}
                    {index === 2 && 'Prémium borélmények'}
                    {index === 3 && 'Hagyományos receptek'}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-5 bg-primary text-white">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-lg-8">
              <h2 className="display-6 fw-bold">Kérdésed van?</h2>
              <p className="lead mb-0">Ne habozz felvenni velünk a kapcsolatot! Szívesen válaszolunk minden kérdésedre.</p>
            </div>
            <div className="col-lg-4 text-lg-end text-center mt-4 mt-lg-0">
              <Link to="/foglalas" className="btn btn-light btn-lg px-5">Kapcsolat</Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;