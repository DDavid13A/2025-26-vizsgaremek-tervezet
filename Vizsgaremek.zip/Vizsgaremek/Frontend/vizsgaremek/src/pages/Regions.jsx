import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { REGIONS_DATA } from '../data/constants';
import './Regions.css';

const Regions = () => {
  const [activeFilter, setActiveFilter] = useState('all');
  
  const regionFilters = [
    { id: 'all', label: 'Összes' },
    { id: 'balaton', label: 'Balaton' },
    { id: 'alfold', label: 'Alföld' },
    { id: 'budapest', label: 'Budapest' },
    { id: 'eszak', label: 'Észak' },
    { id: 'del', label: 'Dél' },
    { id: 'nyugat', label: 'Nyugat' }
  ];

  const filteredRegions = activeFilter === 'all' 
    ? REGIONS_DATA 
    : REGIONS_DATA.filter(region => region.id === activeFilter);

  return (
    <div className="regions-page">
      {/* Page Header */}
      <section className="page-header">
        <div className="container">
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item"><Link to="/">Kezdőlap</Link></li>
              <li className="breadcrumb-item active" aria-current="page">Tájegységek</li>
            </ol>
          </nav>
          <h1>Gasztronómiai Tájegységeink</h1>
          <p className="lead">
            Fedezd fel Magyarország 7 gasztronómiai régióját, ahol minden terület sajátos ízekkel, 
            hagyományokkal és helyi specialitásokkal várja a vendégeket.
          </p>
        </div>
      </section>

      {/* Region Filter */}
      <section className="py-4 bg-light">
        <div className="container">
          <div className="d-flex flex-wrap justify-content-center gap-2">
            {regionFilters.map(filter => (
              <button
                key={filter.id}
                className={`btn btn-outline-primary region-filter ${activeFilter === filter.id ? 'active' : ''}`}
                onClick={() => setActiveFilter(filter.id)}
                data-region={filter.id}
              >
                {filter.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Regions Grid */}
      <section className="py-5">
        <div className="container">
          <div className="row g-4">
            {filteredRegions.map(region => (
              <div className="col-lg-6" key={region.id} id={region.id}>
                <div className="region-card h-100">
                  <div className="row g-0">
                    <div className="col-md-6">
                      <img 
                        src={region.image} 
                        className="img-fluid h-100 region-card-img" 
                        alt={region.name} 
                        style={{ objectFit: 'cover' }}
                      />
                    </div>
                    <div className="col-md-6">
                      <div className="region-card-body">
                        <h3 className="region-card-title">{region.name}</h3>
                        <p>{region.description}</p>
                        
                        <div className="region-features mt-3">
                          <h5>Jellegzetes ételek:</h5>
                          <ul>
                            {region.specialties?.map((item, index) => (
                              <li key={index}>{item}</li>
                            ))}
                          </ul>
                          
                          {region.wineRegions && (
                            <>
                              <h5 className="mt-3">Legjobb borvidékek:</h5>
                              <ul>
                                {region.wineRegions.map((wine, index) => (
                                  <li key={index}>{wine}</li>
                                ))}
                              </ul>
                            </>
                          )}
                          
                          {region.cities && (
                            <>
                              <h5 className="mt-3">Híres városok:</h5>
                              <ul>
                                {region.cities.map((city, index) => (
                                  <li key={index}>{city}</li>
                                ))}
                              </ul>
                            </>
                          )}
                        </div>
                        
                        <div className="mt-3">
                          <Link to={`/programok?region=${region.id}`} className="btn btn-primary">
                            Programok a régióban
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Region Comparison */}
      <section className="py-5 bg-light">
        <div className="container">
          <div className="row mb-5">
            <div className="col-lg-8 mx-auto text-center">
              <h2 className="section-title text-center">Régiók összehasonlítása</h2>
              <p className="lead">Válaszd ki számodra leginkább megfelelő gasztronómiai régiót!</p>
            </div>
          </div>
          
          <div className="table-responsive">
            <table className="table table-hover">
              <thead>
                <tr>
                  <th>Régió</th>
                  <th>Jellegzetes ízek</th>
                  <th>Legnépszerűbb ételek</th>
                  <th>Borajánlat</th>
                  <th>Legjobb időszak</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><strong>Balaton-felvidék</strong></td>
                  <td>Hal, frissesség, bor</td>
                  <td>Halászlé, fogas sült</td>
                  <td>Fehérborok dominálnak</td>
                  <td>Május - Szeptember</td>
                </tr>
                <tr>
                  <td><strong>Alföld</strong></td>
                  <td>Fűszeres, húsos, gazdag</td>
                  <td>Szegedi halászlé, kolbász</td>
                  <td>Vörösborok, pálinkák</td>
                  <td>Egész évben</td>
                </tr>
                <tr>
                  <td><strong>Budapest</strong></td>
                  <td>Világkonyha, fúzió</td>
                  <td>Új magyar gasztronómia</td>
                  <td>Választék mindenből</td>
                  <td>Egész évben</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-5">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-lg-8">
              <h2 className="display-6 fw-bold">Már döntöttél melyik régió érdekel?</h2>
              <p className="lead mb-0">Nézd meg a programjainkat a kiválasztott régióban, és foglalj időpontot!</p>
            </div>
            <div className="col-lg-4 text-lg-end text-center mt-4 mt-lg-0">
              <Link to="/programok" className="btn btn-primary btn-lg px-5">Programok böngészése</Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Regions;