import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { PROGRAM_NAMES } from '../data/constants';
import './Success.css';

const Success = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [bookingData, setBookingData] = useState(null);
  const [countdown, setCountdown] = useState(5);

  useEffect(() => {
    const bookingId = searchParams.get('id');
    if (bookingId) {
      const bookings = JSON.parse(localStorage.getItem('gasztroBookings') || '[]');
      const booking = bookings.find(b => b.id == bookingId);
      setBookingData(booking);
    }

    // Countdown timer
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          navigate('/');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [navigate, searchParams]);

  return (
    <div className="success-page">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-lg-8 text-center">
            <div className="success-icon">
              <i className="bi bi-check-circle"></i>
            </div>
            
            <h1 className="display-4 fw-bold text-success mb-4">Foglalás sikeres!</h1>
            
            <div className="alert alert-success alert-dismissible fade show" role="alert">
              <h4 className="alert-heading">Köszönjük a foglalásod!</h4>
              <p>A foglalás részleteit elküldtük az email címedre. Kérjük, ellenőrizd a beérkezett leveleket (és a spam mappát is).</p>
              <hr />
              <p className="mb-0">
                Amennyiben 24 órán belül nem kapod meg az emailt, kérjük, lépj kapcsolatba velünk a{' '}
                <strong>info@gasztromagyarorszag.hu</strong> email címen.
              </p>
            </div>
            
            {/* Booking Details */}
            {bookingData && (
              <div className="my-5">
                <div className="card border-0 shadow-lg">
                  <div className="card-header bg-success text-white">
                    <h4 className="mb-0">
                      <i className="bi bi-receipt me-2"></i>Foglalási összegzés
                    </h4>
                  </div>
                  <div className="card-body">
                    <div className="row">
                      <div className="col-md-6">
                        <h5>Személyes adatok</h5>
                        <p>
                          <strong>Név:</strong> {bookingData.firstName} {bookingData.lastName}
                        </p>
                        <p>
                          <strong>Email:</strong> {bookingData.email}
                        </p>
                        <p>
                          <strong>Telefon:</strong> {bookingData.phone}
                        </p>
                      </div>
                      <div className="col-md-6">
                        <h5>Foglalás részletei</h5>
                        <p>
                          <strong>Program:</strong> {PROGRAM_NAMES[bookingData.program] || bookingData.program}
                        </p>
                        <p>
                          <strong>Dátum:</strong> {bookingData.date}
                        </p>
                        <p>
                          <strong>Időpont:</strong> {bookingData.time || 'Nincs megadva'}
                        </p>
                        <p>
                          <strong>Résztvevők:</strong> {bookingData.participants} fő
                        </p>
                        {bookingData.children > 0 && (
                          <p>
                            <strong>Gyermekek (6-12 év):</strong> {bookingData.children} fő
                          </p>
                        )}
                      </div>
                    </div>
                    
                    {bookingData.specialRequests && (
                      <div className="mt-4">
                        <h5>Speciális kérések</h5>
                        <p className="mb-0">{bookingData.specialRequests}</p>
                      </div>
                    )}
                    
                    <div className="mt-4 pt-3 border-top">
                      <div className="row">
                        <div className="col-6">
                          <h5>Foglalási azonosító:</h5>
                          <p className="h4 text-success">GM-{bookingData.id}</p>
                        </div>
                        <div className="col-6 text-end">
                          <h5>Fizetendő összeg:</h5>
                          <p className="h4 text-success">{bookingData.totalPrice || '0 Ft'}</p>
                        </div>
                      </div>
                      <p className="text-muted small mt-2">
                        A foglalás státusza: <span className="badge bg-warning">Fizetésre vár</span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            <div className="card border-0 shadow-sm mb-5">
              <div className="card-body">
                <h5 className="card-title">Következő lépések</h5>
                <ol className="text-start">
                  <li className="mb-2">Ellenőrizd az email fiókodat a részletes információkért</li>
                  <li className="mb-2">A fizetés megerősítéséhez kövesd az emailben található utasításokat</li>
                  <li className="mb-2">A program napján legyél időben a megadott helyszínen</li>
                  <li className="mb-2">Hozd magaddal a személyi igazolványodat</li>
                  <li>Kérdezz bátran, ha bármi kérdésed van!</li>
                </ol>
              </div>
            </div>
            
            <div className="row g-4">
              <div className="col-md-4">
                <div className="card border-0 h-100">
                  <div className="card-body text-center">
                    <i className="bi bi-envelope fs-1 text-primary mb-3"></i>
                    <h5>Email</h5>
                    <p className="mb-0">info@gasztromagyarorszag.hu</p>
                  </div>
                </div>
              </div>
              <div className="col-md-4">
                <div className="card border-0 h-100">
                  <div className="card-body text-center">
                    <i className="bi bi-telephone fs-1 text-primary mb-3"></i>
                    <h5>Telefon</h5>
                    <p className="mb-0">+36 1 234 5678</p>
                  </div>
                </div>
              </div>
              <div className="col-md-4">
                <div className="card border-0 h-100">
                  <div className="card-body text-center">
                    <i className="bi bi-clock fs-1 text-primary mb-3"></i>
                    <h5>Nyitvatartás</h5>
                    <p className="mb-0">H-P: 9:00-18:00</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-5">
              <p>
                Az oldal automatikusan visszairányít a kezdőlapra{' '}
                <span id="countdown" className="fw-bold">{countdown}</span> másodperc múlva.
              </p>
              <div className="d-flex justify-content-center gap-3 flex-wrap">
                <button onClick={() => navigate('/')} className="btn btn-primary btn-lg">
                  Vissza a kezdőlapra
                </button>
                <button onClick={() => navigate('/programok')} className="btn btn-outline-primary btn-lg">
                  További programok
                </button>
                <button onClick={() => navigate('/foglalas')} className="btn btn-outline-success btn-lg">
                  Új foglalás
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Success;