import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { PROGRAM_PRICES, PROGRAM_NAMES, PROGRAM_REGIONS } from '../data/constants';
import './Booking.css';

const Booking = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  
  const [formData, setFormData] = useState({
    program: '',
    region: '',
    date: '',
    time: '',
    participants: 1,
    children: 0,
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    specialRequests: '',
    dietVegetarian: false,
    dietVegan: false,
    dietGlutenFree: false,
    dietLactoseFree: false,
    dietDiabetic: false,
    dietOther: false,
    otherDietText: '',
    paymentMethod: 'card',
    terms: false,
    newsletter: false
  });

  const [errors, setErrors] = useState({});

  useEffect(() => {
    // Set default date (tomorrow)
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const formattedDate = tomorrow.toISOString().split('T')[0];
    
    setFormData(prev => ({
      ...prev,
      date: formattedDate
    }));

    // Get program from URL params
    const programParam = searchParams.get('program');
    if (programParam) {
      setFormData(prev => ({
        ...prev,
        program: programParam
      }));
    }
  }, [searchParams]);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));

    // Clear error for this field
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }

    // Update regions when program changes
    if (name === 'program' && value) {
      setFormData(prev => ({
        ...prev,
        region: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.program) newErrors.program = 'Kérjük, válassz egy programot!';
    if (formData.program && PROGRAM_REGIONS[formData.program] && !formData.region) {
      newErrors.region = 'Kérjük, válassz egy régiót!';
    }
    if (!formData.date) newErrors.date = 'Kérjük, válassz egy dátumot!';
    if (!formData.time) newErrors.time = 'Kérjük, válassz egy időpontot!';
    if (!formData.firstName) newErrors.firstName = 'Kérjük, add meg a keresztneved!';
    if (!formData.lastName) newErrors.lastName = 'Kérjük, add meg a vezetékneved!';
    if (!formData.email) newErrors.email = 'Kérjük, add meg az email címed!';
    if (!formData.phone) newErrors.phone = 'Kérjük, add meg a telefonszámod!';
    if (!formData.terms) newErrors.terms = 'El kell fogadnod az Általános Szerződési Feltételeket!';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const calculateTotal = () => {
    if (!formData.program || !PROGRAM_PRICES[formData.program]) return 0;
    
    const pricePerPerson = PROGRAM_PRICES[formData.program];
    const participants = parseInt(formData.participants) || 0;
    const children = parseInt(formData.children) || 0;
    
    const adultTotal = participants * pricePerPerson;
    const childrenTotal = children * (pricePerPerson * 0.7); // 30% discount
    return adultTotal + childrenTotal;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (validateForm()) {
      // Save to localStorage
      const booking = {
        ...formData,
        id: Date.now(),
        status: 'pending',
        createdAt: new Date().toISOString(),
        totalPrice: calculateTotal().toLocaleString('hu-HU') + ' Ft'
      };
      
      const bookings = JSON.parse(localStorage.getItem('gasztroBookings') || '[]');
      bookings.push(booking);
      localStorage.setItem('gasztroBookings', JSON.stringify(bookings));
      
      // Navigate to success page
      navigate(`/sikeres-foglalas?id=${booking.id}`);
    }
  };

  const totalPrice = calculateTotal();
  const pricePerPerson = formData.program ? PROGRAM_PRICES[formData.program] || 0 : 0;
  const showRegionSelect = formData.program && PROGRAM_REGIONS[formData.program];

  return (
    <div className="booking-page">
      {/* Page Header */}
      <section className="page-header">
        <div className="container">
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item"><a href="/">Kezdőlap</a></li>
              <li className="breadcrumb-item active" aria-current="page">Foglalás</li>
            </ol>
          </nav>
          <h1>Online Foglalás</h1>
          <p className="lead">Foglalj időpontot könnyedén online, és fedezd fel Magyarország gasztronómiai kincseit!</p>
        </div>
      </section>

      {/* Booking Process */}
      <section className="py-5">
        <div className="container">
          {/* Booking Steps */}
          <div className="row mb-5">
            <div className="col-12">
              <div className="d-flex justify-content-center">
                {[1, 2, 3, 4].map((step) => (
                  <React.Fragment key={step}>
                    <div className="text-center mx-4">
                      <div className={`rounded-circle ${step === 1 ? 'bg-primary' : 'bg-secondary'} text-white d-inline-flex align-items-center justify-content-center mb-2`} 
                           style={{ width: '50px', height: '50px' }}>
                        {step}
                      </div>
                      <p className="mb-0">
                        <strong>
                          {step === 1 && 'Program választás'}
                          {step === 2 && 'Dátum választás'}
                          {step === 3 && 'Személyes adatok'}
                          {step === 4 && 'Megerősítés'}
                        </strong>
                      </p>
                    </div>
                    {step < 4 && (
                      <div className="align-self-center mx-2">
                        <i className="bi bi-chevron-right text-muted"></i>
                      </div>
                    )}
                  </React.Fragment>
                ))}
              </div>
            </div>
          </div>

          {/* Booking Form */}
          <div className="row">
            <div className="col-lg-8 mx-auto">
              <div className="booking-form">
                <form onSubmit={handleSubmit} noValidate>
                  <h3 className="mb-4">1. Válassz programot</h3>
                  
                  {/* Program Selection */}
                  <div className="row mb-4">
                    <div className="col-12">
                      <label htmlFor="program" className="form-label fw-bold">Program típusa *</label>
                      <select 
                        className={`form-select form-select-lg ${errors.program ? 'is-invalid' : ''}`}
                        id="program"
                        name="program"
                        value={formData.program}
                        onChange={handleInputChange}
                        required
                      >
                        <option value="" disabled>Válassz egy programot...</option>
                        <option value="etterem">Étterem Kóstoló (8.900 Ft/fő)</option>
                        <option value="fozokurzus">Főzőkurzus (12.500 Ft/fő)</option>
                        <option value="pincelatogatas">Pincelátogatás (9.500 Ft/fő)</option>
                        <option value="gasztrotura">Tematikus Gasztrotúra (25.000 Ft/fő)</option>
                        <option value="piac">Piaci vásárlás és főzés (15.000 Ft/fő)</option>
                        <option value="fesztival">Gasztro Fesztivál (ár egyedi)</option>
                      </select>
                      {errors.program && <div className="invalid-feedback">{errors.program}</div>}
                    </div>
                  </div>
                  
                  {/* Region Selection (dynamic) */}
                  {showRegionSelect && (
                    <div className="row mb-4">
                      <div className="col-12">
                        <label htmlFor="region" className="form-label fw-bold">Régió *</label>
                        <select 
                          className={`form-select ${errors.region ? 'is-invalid' : ''}`}
                          id="region"
                          name="region"
                          value={formData.region}
                          onChange={handleInputChange}
                          required
                        >
                          <option value="" disabled>Válassz egy régiót...</option>
                          {PROGRAM_REGIONS[formData.program].map(region => (
                            <option key={region} value={region.toLowerCase().replace(/ /g, '-')}>
                              {region}
                            </option>
                          ))}
                        </select>
                        {errors.region && <div className="invalid-feedback">{errors.region}</div>}
                      </div>
                    </div>
                  )}
                  
                  {/* Date Selection */}
                  <h3 className="mb-4 mt-5">2. Válassz dátumot</h3>
                  <div className="row mb-4">
                    <div className="col-md-6 mb-3">
                      <label htmlFor="date" className="form-label fw-bold">Dátum *</label>
                      <input 
                        type="date" 
                        className={`form-control ${errors.date ? 'is-invalid' : ''}`}
                        id="date"
                        name="date"
                        value={formData.date}
                        onChange={handleInputChange}
                        required
                        min={new Date().toISOString().split('T')[0]}
                      />
                      {errors.date && <div className="invalid-feedback">{errors.date}</div>}
                      <div className="form-text">Legkorábban holnapra, legkésőbb 3 hónappal előre foglalhatsz.</div>
                    </div>
                    <div className="col-md-6 mb-3">
                      <label htmlFor="time" className="form-label fw-bold">Időpont *</label>
                      <select 
                        className={`form-select ${errors.time ? 'is-invalid' : ''}`}
                        id="time"
                        name="time"
                        value={formData.time}
                        onChange={handleInputChange}
                        required
                      >
                        <option value="" disabled>Válassz időpontot...</option>
                        <option value="10:00">10:00</option>
                        <option value="11:00">11:00</option>
                        <option value="12:00">12:00</option>
                        <option value="14:00">14:00</option>
                        <option value="15:00">15:00</option>
                        <option value="16:00">16:00</option>
                        <option value="18:00">18:00</option>
                        <option value="19:00">19:00</option>
                        <option value="20:00">20:00</option>
                      </select>
                      {errors.time && <div className="invalid-feedback">{errors.time}</div>}
                    </div>
                  </div>
                  
                  {/* Participants */}
                  <div className="row mb-4">
                    <div className="col-md-6">
                      <label htmlFor="participants" className="form-label fw-bold">Résztvevők száma *</label>
                      <input 
                        type="number" 
                        className="form-control"
                        id="participants"
                        name="participants"
                        value={formData.participants}
                        onChange={handleInputChange}
                        min="1"
                        max="20"
                        required
                      />
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="children" className="form-label fw-bold">Gyermekek száma (6-12 év)</label>
                      <input 
                        type="number" 
                        className="form-control"
                        id="children"
                        name="children"
                        value={formData.children}
                        onChange={handleInputChange}
                        min="0"
                        max="10"
                      />
                      <div className="form-text">Gyermekek részére 30% kedvezményt biztosítunk.</div>
                    </div>
                  </div>
                  
                  {/* Personal Details */}
                  <h3 className="mb-4 mt-5">3. Személyes adatok</h3>
                  <div className="row mb-3">
                    <div className="col-md-6 mb-3">
                      <label htmlFor="firstName" className="form-label fw-bold">Keresztnév *</label>
                      <input 
                        type="text" 
                        className={`form-control ${errors.firstName ? 'is-invalid' : ''}`}
                        id="firstName"
                        name="firstName"
                        value={formData.firstName}
                        onChange={handleInputChange}
                        required
                      />
                      {errors.firstName && <div className="invalid-feedback">{errors.firstName}</div>}
                    </div>
                    <div className="col-md-6 mb-3">
                      <label htmlFor="lastName" className="form-label fw-bold">Vezetéknév *</label>
                      <input 
                        type="text" 
                        className={`form-control ${errors.lastName ? 'is-invalid' : ''}`}
                        id="lastName"
                        name="lastName"
                        value={formData.lastName}
                        onChange={handleInputChange}
                        required
                      />
                      {errors.lastName && <div className="invalid-feedback">{errors.lastName}</div>}
                    </div>
                  </div>
                  
                  <div className="row mb-3">
                    <div className="col-md-6 mb-3">
                      <label htmlFor="email" className="form-label fw-bold">Email cím *</label>
                      <input 
                        type="email" 
                        className={`form-control ${errors.email ? 'is-invalid' : ''}`}
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                      />
                      {errors.email && <div className="invalid-feedback">{errors.email}</div>}
                    </div>
                    <div className="col-md-6 mb-3">
                      <label htmlFor="phone" className="form-label fw-bold">Telefonszám *</label>
                      <input 
                        type="tel" 
                        className={`form-control ${errors.phone ? 'is-invalid' : ''}`}
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        required
                      />
                      {errors.phone && <div className="invalid-feedback">{errors.phone}</div>}
                    </div>
                  </div>
                  
                  {/* Special Requests */}
                  <div className="mb-4">
                    <label htmlFor="specialRequests" className="form-label fw-bold">Speciális igények / megjegyzések</label>
                    <textarea 
                      className="form-control"
                      id="specialRequests"
                      name="specialRequests"
                      rows="4"
                      value={formData.specialRequests}
                      onChange={handleInputChange}
                      placeholder="Pl. ételallergiák, diétai igények, ünnepi alkalom, egyéb kérések..."
                    />
                  </div>
                  
                  {/* Dietary Requirements */}
                  <div className="mb-4">
                    <label className="form-label fw-bold">Ételallergiák / diétai igények</label>
                    <div className="row">
                      <div className="col-md-6">
                        <div className="form-check">
                          <input 
                            className="form-check-input"
                            type="checkbox"
                            id="dietVegetarian"
                            name="dietVegetarian"
                            checked={formData.dietVegetarian}
                            onChange={handleInputChange}
                          />
                          <label className="form-check-label" htmlFor="dietVegetarian">Vegetáriánus</label>
                        </div>
                        <div className="form-check">
                          <input 
                            className="form-check-input"
                            type="checkbox"
                            id="dietVegan"
                            name="dietVegan"
                            checked={formData.dietVegan}
                            onChange={handleInputChange}
                          />
                          <label className="form-check-label" htmlFor="dietVegan">Vegán</label>
                        </div>
                        <div className="form-check">
                          <input 
                            className="form-check-input"
                            type="checkbox"
                            id="dietGlutenFree"
                            name="dietGlutenFree"
                            checked={formData.dietGlutenFree}
                            onChange={handleInputChange}
                          />
                          <label className="form-check-label" htmlFor="dietGlutenFree">Gluténmentes</label>
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="form-check">
                          <input 
                            className="form-check-input"
                            type="checkbox"
                            id="dietLactoseFree"
                            name="dietLactoseFree"
                            checked={formData.dietLactoseFree}
                            onChange={handleInputChange}
                          />
                          <label className="form-check-label" htmlFor="dietLactoseFree">Laktózmentes</label>
                        </div>
                        <div className="form-check">
                          <input 
                            className="form-check-input"
                            type="checkbox"
                            id="dietDiabetic"
                            name="dietDiabetic"
                            checked={formData.dietDiabetic}
                            onChange={handleInputChange}
                          />
                          <label className="form-check-label" htmlFor="dietDiabetic">Cukorbetegeknek</label>
                        </div>
                        <div className="form-check">
                          <input 
                            className="form-check-input"
                            type="checkbox"
                            id="dietOther"
                            name="dietOther"
                            checked={formData.dietOther}
                            onChange={handleInputChange}
                          />
                          <label className="form-check-label" htmlFor="dietOther">Egyéb</label>
                        </div>
                      </div>
                    </div>
                    {formData.dietOther && (
                      <div className="mt-2">
                        <input 
                          type="text" 
                          className="form-control"
                          id="otherDietText"
                          name="otherDietText"
                          value={formData.otherDietText}
                          onChange={handleInputChange}
                          placeholder="Kérjük, írd le az egyéb diétai igényed..."
                        />
                      </div>
                    )}
                  </div>
                  
                  {/* Payment Method */}
                  <div className="mb-4">
                    <label className="form-label fw-bold">Fizetési mód</label>
                    <div className="form-check">
                      <input 
                        className="form-check-input"
                        type="radio"
                        name="paymentMethod"
                        id="paymentCard"
                        value="card"
                        checked={formData.paymentMethod === 'card'}
                        onChange={handleInputChange}
                      />
                      <label className="form-check-label" htmlFor="paymentCard">Bankkártyás fizetés online</label>
                    </div>
                    <div className="form-check">
                      <input 
                        className="form-check-input"
                        type="radio"
                        name="paymentMethod"
                        id="paymentTransfer"
                        value="transfer"
                        checked={formData.paymentMethod === 'transfer'}
                        onChange={handleInputChange}
                      />
                      <label className="form-check-label" htmlFor="paymentTransfer">Banki átutalás</label>
                    </div>
                    <div className="form-check">
                      <input 
                        className="form-check-input"
                        type="radio"
                        name="paymentMethod"
                        id="paymentCash"
                        value="cash"
                        checked={formData.paymentMethod === 'cash'}
                        onChange={handleInputChange}
                      />
                      <label className="form-check-label" htmlFor="paymentCash">Készpénz a helyszínen</label>
                    </div>
                  </div>
                  
                  {/* Terms and Conditions */}
                  <div className="mb-4">
                    <div className="form-check">
                      <input 
                        className={`form-check-input ${errors.terms ? 'is-invalid' : ''}`}
                        type="checkbox"
                        id="terms"
                        name="terms"
                        checked={formData.terms}
                        onChange={handleInputChange}
                        required
                      />
                      <label className="form-check-label" htmlFor="terms">
                        Elfogadom az Általános Szerződési Feltételeket és hozzájárulok az adatkezeléshez *
                      </label>
                      {errors.terms && <div className="invalid-feedback">{errors.terms}</div>}
                    </div>
                    <div className="form-check mt-2">
                      <input 
                        className="form-check-input"
                        type="checkbox"
                        id="newsletter"
                        name="newsletter"
                        checked={formData.newsletter}
                        onChange={handleInputChange}
                      />
                      <label className="form-check-label" htmlFor="newsletter">
                        Szeretnék hírlevelet kapni az új programokról és ajánlatokról
                      </label>
                    </div>
                  </div>
                  
                  {/* Price Summary */}
                  <div className="card border-0 bg-light mb-4">
                    <div className="card-body">
                      <h5 className="card-title">Összegzés</h5>
                      <div className="row">
                        <div className="col-6">
                          <p className="mb-1">Program ára/fő:</p>
                          <p className="mb-1">Résztvevők:</p>
                          <p className="mb-1">Gyermekek (30% kedvezmény):</p>
                          <hr className="my-2" />
                          <p className="mb-0 fw-bold">Végösszeg:</p>
                        </div>
                        <div className="col-6 text-end">
                          <p className="mb-1" id="pricePerPerson">{pricePerPerson.toLocaleString('hu-HU')} Ft</p>
                          <p className="mb-1" id="participantsCount">
                            {formData.participants} fő × {pricePerPerson.toLocaleString('hu-HU')} Ft
                          </p>
                          <p className="mb-1" id="childrenPrice">
                            {formData.children} fő × {(pricePerPerson * 0.7).toLocaleString('hu-HU')} Ft
                          </p>
                          <hr className="my-2" />
                          <p className="mb-0 fw-bold" id="totalPrice">{totalPrice.toLocaleString('hu-HU')} Ft</p>
                        </div>
                      </div>
                      <div className="mt-2 text-muted small">
                        Az ár tartalmazza az ÁFA-t és az összes szolgáltatást.
                        {parseInt(formData.children) > 0 && ' Gyermekek részére 30% kedvezményt biztosítunk.'}
                        {(parseInt(formData.participants) + parseInt(formData.children)) >= 6 && 
                          ' 6 fő felett 10% csoportkedvezmény érvényesíthető.'}
                      </div>
                    </div>
                  </div>
                  
                  {/* Submit Button */}
                  <div className="d-grid">
                    <button type="submit" className="btn btn-primary btn-lg py-3">
                      <i className="bi bi-calendar-check me-2"></i>Foglalás elküldése és fizetés
                    </button>
                  </div>
                  
                  <div className="text-center mt-3">
                    <p className="text-muted small">A foglalás véglegesítése után emailben kapod meg a részleteket és a fizetési lehetőségeket.</p>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Booking Tips */}
      <section className="py-5 bg-light">
        <div className="container">
          <div className="row">
            <div className="col-lg-10 mx-auto">
              <h3 className="section-title">Foglalási tippek</h3>
              <div className="row g-4">
                <div className="col-md-4">
                  <div className="text-center p-3">
                    <i className="bi bi-calendar2-check fs-1 text-primary mb-3"></i>
                    <h5>Korai foglalás</h5>
                    <p>Népszerű időszakokban és hétvégéken korábban érdemes foglalni, hogy biztosan kapj időpontot.</p>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="text-center p-3">
                    <i className="bi bi-people fs-1 text-primary mb-3"></i>
                    <h5>Csoportkedvezmények</h5>
                    <p>6 fő felett 10%, 10 fő felett 15% csoportkedvezményt biztosítunk. Ideális céges vagy családi programokhoz.</p>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="text-center p-3">
                    <i className="bi bi-question-circle fs-1 text-primary mb-3"></i>
                    <h5>Segítségre van szükséged?</h5>
                    <p>Hívj minket: <strong>+36 1 234 5678</strong> vagy írj emailt: <strong>info@gasztromagyarorszag.hu</strong></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Booking;