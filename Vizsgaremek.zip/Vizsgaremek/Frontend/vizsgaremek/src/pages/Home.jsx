import React from 'react';
import { Link } from 'react-router-dom';
import { REGIONS_DATA, PROGRAMS_DATA } from '../data/constants';
import './Home.css';

const Home = () => {
  return (
    <div className="home-page">
      {/* Hero Section */}
      <section className="hero-section">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-lg-8 mx-auto text-center">
              <h1 className="hero-title">Fedezd fel Magyarország gasztronómiai kincseit!</h1>
              <p className="hero-subtitle">
                Hagyományos ételek, helyi specialitások és felejthetetlen gasztroélmények várnak minden ínyenc utazóra. 
                Csatlakozz hozzánk, és élvezd az ország gasztroturisztikai kínálatát!
              </p>
              <div className="mt-4">
                <Link to="/tajegysgek" className="btn btn-primary btn-lg me-3 mb-3">
                  Fedezzük fel együtt!
                </Link>
                <Link to="/programok" className="btn btn-outline-primary btn-lg mb-3">
                  Programjaink
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="stats-section">
        <div className="container">
          <div className="row text-center">
            <div className="col-md-3 col-6 mb-4 mb-md-0">
              <div className="stat-number">7</div>
              <div className="stat-label">Gasztronómiai Tájegység</div>
            </div>
            <div className="col-md-3 col-6 mb-4 mb-md-0">
              <div className="stat-number">50+</div>
              <div className="stat-label">Gasztroprogram</div>
            </div>
            <div className="col-md-3 col-6">
              <div className="stat-number">120+</div>
              <div className="stat-label">Partnervállalkozás</div>
            </div>
            <div className="col-md-3 col-6">
              <div className="stat-number">4.9</div>
              <div className="stat-label">Átlagos Értékelés</div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Regions */}
      <section className="py-5">
        <div className="container">
          <div className="row mb-5">
            <div className="col-lg-8 mx-auto text-center">
              <h2 className="section-title text-center">Gasztronómiai Tájegységeink</h2>
              <p className="lead">
                Ismerd meg Magyarország gazdag gasztronómiai régióit, ahol minden terület sajátos ízekkel, 
                hagyományokkal és helyi specialitásokkal várja a vendégeket.
              </p>
            </div>
          </div>
          
          <div className="row g-4">
            {REGIONS_DATA.slice(0, 3).map((region) => (
              <div className="col-lg-4 col-md-6" key={region.id}>
                <div className="card region-card">
                  <img src={region.image} className="region-card-img" alt={region.name} />
                  <div className="region-card-body">
                    <h3 className="region-card-title">{region.name}</h3>
                    <p className="card-text">{region.description}</p>
                    <Link to={`/tajegysgek#${region.id}`} className="btn btn-outline-primary mt-3">
                      Részletek
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-5">
            <Link to="/tajegysgek" className="btn btn-primary btn-lg">
              Minden tájegység megtekintése
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Programs */}
      <section className="py-5 bg-light">
        <div className="container">
          <div className="row mb-5">
            <div className="col-lg-8 mx-auto text-center">
              <h2 className="section-title text-center">Népszerű Gasztroprogramjaink</h2>
              <p className="lead">
                Válassz a változatos gasztronómiai programjaink közül - akár egy rövid kóstolót, 
                akár egy többnapos gasztrotúrát szeretnél!
              </p>
            </div>
          </div>
          
          <div className="row g-4">
            {PROGRAMS_DATA.slice(0, 3).map((program) => (
              <div className="col-lg-4 col-md-6" key={program.id}>
                <div className="program-card">
                  <div className="program-icon">
                    <i className={`bi bi-${program.icon}`}></i>
                  </div>
                  <h4>{program.name}</h4>
                  <p>{program.description}</p>
                  <p><strong>Időtartam:</strong> {program.duration}</p>
                  <p><strong>Ár:</strong> {program.price.toLocaleString('hu-HU')} Ft/fő</p>
                  <Link to={`/programok#${program.id}`} className="btn btn-primary">
                    Részletek
                  </Link>
                </div>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-5">
            <Link to="/programok" className="btn btn-outline-primary btn-lg">
              Összes program megtekintése
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-5">
        <div className="container">
          <div className="row mb-5">
            <div className="col-lg-8 mx-auto text-center">
              <h2 className="section-title text-center">Vendégeink véleménye</h2>
              <p className="lead">Hallgasd meg, mit mondanak azok, akik már részt vettek gasztroprogramjainkon!</p>
            </div>
          </div>
          
          <div className="row">
            <div className="col-lg-4 col-md-6">
              <div className="testimonial-card">
                <div className="rating mb-2">
                  <i className="bi bi-star-fill text-warning"></i>
                  <i className="bi bi-star-fill text-warning"></i>
                  <i className="bi bi-star-fill text-warning"></i>
                  <i className="bi bi-star-fill text-warning"></i>
                  <i className="bi bi-star-fill text-warning"></i>
                </div>
                <p>
                  "Csodálatos élmény volt a főzőkurzus a Balaton-felvidéken! Nemcsak finomakat ettünk, 
                  de tényleg megtanultam elkészíteni a klasszikus magyar ételeket. A szakács profi volt és nagyon türelmes."
                </p>
                <div className="testimonial-author">Kovács Anna · Budapest</div>
              </div>
            </div>
            
            <div className="col-lg-4 col-md-6">
              <div className="testimonial-card">
                <div className="rating mb-2">
                  <i className="bi bi-star-fill text-warning"></i>
                  <i className="bi bi-star-fill text-warning"></i>
                  <i className="bi bi-star-fill text-warning"></i>
                  <i className="bi bi-star-fill text-warning"></i>
                  <i className="bi bi-star-fill text-warning"></i>
                </div>
                <p>
                  "Németországból látogattuk meg Magyarországot és ezt a gasztrotúrát választottuk. 
                  Fantasztikus módja volt az ország megismerésének!"
                </p>
                <div className="testimonial-author">Müller Hans · Berlin</div>
              </div>
            </div>
            
            <div className="col-lg-4 col-md-6">
              <div className="testimonial-card">
                <div className="rating mb-2">
                  <i className="bi bi-star-fill text-warning"></i>
                  <i className="bi bi-star-fill text-warning"></i>
                  <i className="bi bi-star-fill text-warning"></i>
                  <i className="bi bi-star-fill text-warning"></i>
                  <i className="bi bi-star-fill text-warning"></i>
                </div>
                <p>
                  "A piaci vásárlás és főzés programon vettem részt barátaimmal. Nagyon interaktív és 
                  szórakoztató volt a piac felismerése, majd a főzés együtt."
                </p>
                <div className="testimonial-author">Tóth Gábor · Szeged</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-5 bg-primary text-white">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-lg-8">
              <h2 className="display-6 fw-bold">Készen állsz a gasztroélményre?</h2>
              <p className="lead mb-0">Foglalj időpontot még ma, és fedezd fel Magyarország gasztronómiai kincseit!</p>
            </div>
            <div className="col-lg-4 text-lg-end text-center mt-4 mt-lg-0">
              <Link to="/foglalas" className="btn btn-light btn-lg px-5">Foglalás most</Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;