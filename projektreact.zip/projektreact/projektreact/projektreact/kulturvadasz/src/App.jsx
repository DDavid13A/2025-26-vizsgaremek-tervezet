import React from 'react';
import './App.css';
import './components/Buttons.css'; // Import the buttons CSS
import Home from './pages/Home';

function App() {
  return <Home />;
}

export default App;