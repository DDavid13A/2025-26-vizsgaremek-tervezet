import React from 'react';
import { MapPin, Calendar, Star, Users, Clock, ChevronRight } from 'lucide-react';
import './program.css';

const ProgramsSection = () => {
  const programs = [
    {
      id: 1,
      title: 'Tokaji Borkóstoló és Pincelátogatás',
      region: 'Észak-Magyarország',
      date: '2023.10.15',
      category: 'Bor & Borkóstoló',
      price: 8900,
      rating: 4.8,
      participants: 12,
      duration: '3 óra',
      image: 'https://images.unsplash.com/photo-1506377247377-2a5b3b417ebb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80'
    },
    {
      id: 2,
      title: 'Hagyományos Szalonnafüstölés Tanfolyam',
      region: 'Alföld',
      date: '2023.10.20',
      category: 'Tanfolyam',
      price: 12500,
      rating: 4.9,
      participants: 8,
      duration: '4 óra',
      image: 'https://images.unsplash.com/photo-1544025162-d76694265947?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80'
    },
    {
      id: 3,
      title: 'Balatoni Halászlé Készítés Mesterfokon',
      region: 'Balaton',
      date: '2023.10.18',
      category: 'Tanfolyam',
      price: 7500,
      rating: 4.7,
      participants: 10,
      duration: '2.5 óra',
      image: 'https://images.unsplash.com/photo-1476224203421-9ac39bcb3327?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80'
    },
    {
      id: 4,
      title: 'Budapest Street Food Séta',
      region: 'Budapest',
      date: '2023.10.22',
      category: 'Gasztro túra',
      price: 6500,
      rating: 4.6,
      participants: 15,
      duration: '3 óra',
      image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80'
    },
  ];

  return (
    <section className="programs-section">
      <div className="container">
        <div className="section-header">
          <h2>Kiemelt Gasztroprogramok</h2>
          <p>Válogass népszerű gasztronómiai élményeink közül</p>
          <a href="#" className="view-all">Összes program megtekintése <ChevronRight size={16} /></a>
        </div>
        
        <div className="programs-grid">
          {programs.map(program => (
            <div key={program.id} className="program-card">
              <div className="program-image" style={{ backgroundImage: `url(${program.image})` }}>
                <span className="program-category">{program.category}</span>
                <span className="program-price">{program.price.toLocaleString()} Ft</span>
              </div>
              
              <div className="program-content">
                <div className="program-header">
                  <h3>{program.title}</h3>
                  <div className="program-rating">
                    <Star size={16} fill="#FFD700" />
                    <span>{program.rating}</span>
                  </div>
                </div>
                
                <div className="program-meta">
                  <span><MapPin size={14} /> {program.region}</span>
                  <span><Calendar size={14} /> {program.date}</span>
                </div>
                
                <p className="program-description">
                  Élvezd a régió autentikus gasztronómiai kincseit és ismerd meg a helyi hagyományokat.
                </p>
                
                <div className="program-footer">
                  <div className="program-stats">
                    <span><Users size={14} /> {program.participants} fő</span>
                    <span><Clock size={14} /> {program.duration}</span>
                  </div>
                  <button className="btn-program">Részletek</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProgramsSection;