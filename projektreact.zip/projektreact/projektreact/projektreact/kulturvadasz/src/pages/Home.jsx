import React from 'react';
import Header from '../components/Header';
import SearchSection from '../components/Search';
import MapSection from '../components/Map';
import ProgramsSection from '../components/Program';
import Footer from '../components/Footer';

const Home = () => {
  return (
    <div className="app">
      <Header />
      <main>
        <SearchSection />
        <MapSection />
        <ProgramsSection />
      </main>
      <Footer />
    </div>
  );
};

export default Home;