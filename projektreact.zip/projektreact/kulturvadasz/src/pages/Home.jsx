import React from 'react';
import Header from '../components/Header';
import SearchSection from '../components/SearchSection';
import MapSection from '../components/MapSection';
import ProgramsSection from '../components/ProgramsSection';
import Footer from '/components/Footer';

const Home = () => {
  return (
    <div className="app">
      <Header />
      <main>
        <SearchSection />
        <MapSection />
        <ProgramsSection />
      </main>
      <Footer />
    </div>
  );
};

export default Home;