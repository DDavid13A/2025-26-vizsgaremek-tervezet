import React from 'react';
import Navigation from '/Navigation';

const Header = () => {
  return (
    <header className="header">
      <div className="container header-content">
        <div className="logo">
          <h1>Kultur<span>Vadász</span></h1>
          <p className="tagline">Gasztroturizmus & Tájak Felfedezése</p>
        </div>
        <Navigation />
        <div className="user-actions">
          <button className="btn-secondary">Bejelentkezés</button>
          <button className="btn-primary">Regisztráció</button>
        </div>
      </div>
    </header>
  );
};

export default Header;