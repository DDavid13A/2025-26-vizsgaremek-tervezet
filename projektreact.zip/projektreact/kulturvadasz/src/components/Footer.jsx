import React from 'react';
import { ChevronRight } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-section">
            <div className="logo">
              <h2>Kultur<span>Vadász</span></h2>
              <p>Gasztroturizmus & Tájak Felfedezése</p>
            </div>
            <p className="footer-description">
              KulturVadász célja, hogy összekösse az utazási és gasztronómiai élményeket, lehetővé téve mindenkinek, hogy felfedezze Magyarország gasztro kincseit.
            </p>
          </div>
          
          <div className="footer-section">
            <h3>Oldalak</h3>
            <ul>
              <li><a href="#">Kezdőlap</a></li>
              <li><a href="#">Programok</a></li>
              <li><a href="#">Tájak</a></li>
              <li><a href="#">Gasztronómia</a></li>
              <li><a href="#">Rólunk</a></li>
            </ul>
          </div>
          
          <div className="footer-section">
            <h3>Kapcsolat</h3>
            <ul>
              <li><a href="#">info@kulturvadasz.hu</a></li>
              <li><a href="#">+36 1 234 5678</a></li>
              <li>Budapest, Gasztro utca 1.</li>
            </ul>
          </div>
          
          <div className="footer-section">
            <h3>Hírlevél</h3>
            <p>Iratkozz fel hírlevelünkre, hogy értesülj legújabb programjainkról!</p>
            <div className="newsletter-form">
              <input type="email" placeholder="Email címed" />
              <button>Feliratkozás</button>
            </div>
          </div>
        </div>
        
        <div className="footer-bottom">
          <p>&copy; 2023 KulturVadász. Minden jog fenntartva.</p>
          <div className="footer-links">
            <a href="#">Adatvédelem</a>
            <a href="#">Felhasználási feltételek</a>
            <a href="#">Sütik kezelése</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;